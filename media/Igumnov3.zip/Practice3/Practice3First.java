/* Igumnov Oleksandr Practice3 First*/
import stanford.karel.*;

public class Practice3First extends SuperKarel{

	public void run(){
		for(int i = 0; i < 2; i++) {
			move();
			putBeeper();
		}
		move();
		turnLeft();
		for(int i = 0; i < 4; i++) {
			move();
			putBeeper();
		}
		move();
		turnLeft();
		for(int i = 0; i < 2; i++) {
			move();
			putBeeper();
		}
		move();
		turnLeft();
		for(int i = 0; i < 4; i++) {
			move();
			putBeeper();
		}
		move();
		turnLeft();
	}
}
