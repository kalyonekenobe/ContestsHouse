/* Igumnov Oleksandr Practice3 Second */
import stanford.karel.*;

public class Practice3Second extends SuperKarel{

	public void run(){
		goToNewspaper();
		pickBeeper();
		returnToStart();
		putBeeper();
	}
	
	private void goToNewspaper() {
		while(frontIsClear()) {
			move();
		}
		turnRight();
		move();
		turnLeft();
		move();
	}
	
	private void returnToStart() {
		turnAround();
		move();
		turnRight();
		move();
		turnLeft();
		while(frontIsClear()) {
			move();
		}
		turnAround();
	}
}
