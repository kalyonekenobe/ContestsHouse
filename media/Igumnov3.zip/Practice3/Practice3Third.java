/* Igumnov Oleksandr Practice3 Third */
import stanford.karel.SuperKarel;

public class Practice3Third extends SuperKarel{
	
	public void run() {
		while(frontIsClear()) {
			turnLeft();
			buildColumn();
			turnLeft();
			goNext();
		}
		turnLeft();
		buildColumn();
		turnLeft();
	}
	
	private void leaveBeepers() {
		while(frontIsClear()) {
			if(noBeepersPresent()) {
				putBeeper();
			}
			move();
		}
	}
	
	private void goNext() {
		for(int i = 0; i < 4; i++) {
			if(frontIsClear())
				move();
		}
	}
	
	private void buildColumn() {
		leaveBeepers();
		if(noBeepersPresent())
			putBeeper();
		turnAround();
		leaveBeepers();
	}

}