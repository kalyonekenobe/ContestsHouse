/* Igumnov Oleksandr HomeWork 2 - First */
import stanford.karel.*;

public class HW2First extends SuperKarel{

	public void run(){
		moveForward();
		if(noBeepersPresent())
			searchExit();
		pickBeeper();
		turnAround();
		moveBack();
	}
	
	private void moveForward() {
		while(frontIsClear() && noBeepersPresent()) {
			move();
		}
	}
	
	private void searchExit() {
		turnRight();
		while(leftIsBlocked()) {
			move();
		}
		turnLeft();
		move();
	}
	private void moveBack() {
		move();
		if(rightIsClear()) {
			turnRight();
			while(frontIsClear()) {
				move();
			}
			turnLeft();
		}
		moveForward();
		turnAround();
	}
}
