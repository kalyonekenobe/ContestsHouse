/* Igumnov Oleksandr HomeWork 2 - Second */
import stanford.karel.*;

public class HW2Second extends SuperKarel{

	public void run(){
		while(frontIsClear() || leftIsClear()) {
			tryMoveEast();
			tryMoveWest();
			tryTurnAround();
		}
	}
	
	private void tryTurnAround() {
		if(frontIsBlocked() && facingWest())
			turnAround();
	}
	
	private void tryMoveWest() {
		while(frontIsClear() && facingWest()) {
			exploreWest();
		}
		if(facingWest())
			exploreWest();
	}
	
	private void tryMoveEast() {
		while(frontIsClear() && facingEast()) {
			exploreEast();
		}
		if(facingEast())
			exploreEast();
	}
	
	private void exploreWest() {
		if(rightIsClear()) {
			turnRight();
			move();
			turnRight();
		}else if(frontIsClear()){
			move();
		}
	}
	
	private void exploreEast() {
		if(leftIsClear()) {
			turnLeft();
			move();
			if(frontIsClear())
				turnRight();
			else 
				turnLeft();
		}else if(frontIsClear()){
			move();
		}
	}
}
