/* Igumnov Oleksandr Homework 3 - First */
import stanford.karel.*;

public class HW3First extends SuperKarel{

	public void run(){
		while(frontIsClear() || notFacingNorth()) {
			moveEast();
			moveWest();
		}
		turnRight();
		goToFinish();
	}
	
	public void moveEast() {
		// fill the odd rows
		
		if(facingEast()) {
			putBeeper();
			while(frontIsClear()) {
				move();
				if(frontIsClear()) {
					move();
					putBeeper();
				}
			}
			stepBackIfNeed();
			turnLeft();
			if(frontIsClear()) {
				move();
				turnLeft();
			}
		}
	}
	
	public void moveWest() {
		// fill the even rows
		
		if(facingWest()) {
			while(frontIsClear()) {	
				putBeeper();
				move();
				if(frontIsClear()) {
					move();
				}
			}
			stepBackIfNeed();
			turnRight();
			if(frontIsClear()) {
				move();
				turnRight();
			}
		}
	}
	
	public void stepBackIfNeed() {
		// step back if the number of columns is odd
		
		if(frontIsBlocked() && beepersPresent()) {
			turnAround();
			if(frontIsClear())
				move();
			turnAround();
		}
	}
	
	public void goToFinish() {
		// go to the finish
		
		while(frontIsClear()) {
			move();
		}
	}
}
