import stanford.karel.*;

public class ErrorsTest extends Karel{

	public void run(){
		move();
		pickBeeper();
		move();
		turnLeft();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		putBeeper();
		move();
		move();
		move();
	}
}
