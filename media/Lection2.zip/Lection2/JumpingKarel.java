import stanford.karel.*;

public class JumpingKarel extends SuperKarel{

	public void run(){
		for (int i = 0; i<8;i++){
			if (frontIsBlocked()){
				jumpBuilding();
			}else {
				move();
			}
		}
	}
	
	private void jumpBuilding(){
		topJump();
		move();
		downJump();
	}
	
	private void topJump(){
		turnLeft();
		while(rightIsBlocked()){
			move();
		}
		turnRight();
	}
	
	private void downJump(){
		turnRight();
		while(frontIsClear()){
			move();
		}
		turnLeft();
	}
}
