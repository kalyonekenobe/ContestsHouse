import stanford.karel.*;

public class SecondProgram extends SuperKarel{

	public void run(){
		while(frontIsClear()){
			move();
		}
		turnLeft();
		move();
		turnRight();
		for(int i=0;i<4;i++){
			move();
		}
	}
	
}
