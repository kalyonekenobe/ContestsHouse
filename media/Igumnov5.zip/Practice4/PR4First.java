/* Oleksandr Igumnov Practice 3 - First */
import stanford.karel.*;

public class PR4First extends SuperKarel{

	public void run(){
		clearRow();
		while(frontIsClear() || leftIsClear()) {
			tryMoveEast();
			tryMoveWest();
			tryTurnAround();
		}
	}
	
	public void clearRow() {
		// Go through the whole row
		
		if(facingEast()) {
			moveThroughRow();
			turnAround();
		}else {
			moveThroughRow();
		}
		for(int i = 0; i < 2; i++) {
			moveThroughRow();
		}
	}
	
	public void moveThroughRow() {
		// Go forward and pick beepers
		
		if(beepersPresent()) {
			pickBeeper();
		}
		while(frontIsClear()) {
			if(beepersPresent()) {
				pickBeeper();
			}
			move();
		}
		turnAround();
	}
	
	public void tryTurnAround() {
		// Turn around if Karel see the wall on the west and he can't move forward
		
		if(frontIsBlocked() && facingWest()) {
			turnAround();
		}
	}
	
	public void tryMoveEast() {
		// Explore the east part of row
		
		while(frontIsClear() && facingEast()) {
			exploreEast();
		}
		if(facingEast()) {
			exploreEast();
		}
	}
	
	public void tryMoveWest() {
		// Explore the west part of row
		
		while(frontIsClear() && facingWest()) {
			exploreWest();
		}
		if(facingWest()) {
			exploreWest();
		}
	}
	
	public void exploreEast() {
		// Try to find the exit from the row on the east
		
		if(leftIsClear()) {
			turnLeft();
			move();
			turnLeft();
			clearRow();
		}else if(frontIsClear()){
			move();
		}
	}
	
	private void exploreWest() {
		// Try to find the exit form the row on the west
		
		if(rightIsClear()) {
			turnRight();
			move();
			if(frontIsClear()) {
				turnRight();
			}else {
				turnLeft();
			}
			clearRow();
		}else if(frontIsClear()){
			move();
		}
	}
}
