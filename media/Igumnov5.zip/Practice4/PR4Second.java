/* Oleksandr Igumnov Practice 3 - Second */
import stanford.karel.*;

public class PR4Second extends SuperKarel{

	public void run(){
		turnLeft();
		clearColumn();
		while(frontIsClear() || rightIsClear()) {
			tryMoveNorth();
			tryMoveSouth();
			tryTurnAround();
		}
		turnRight();
	}
	
	public void clearColumn() {
		// Go through the whole column
		
		if(facingNorth()) {
			moveThroughColumn();
			turnAround();
		}else {
			moveThroughColumn();
		}
		for(int i = 0; i < 2; i++) {
			moveThroughColumn();
		}
	}
	
	public void moveThroughColumn() {
		// Go forward and pick beepers
		
		if(beepersPresent()) {
			pickBeeper();
		}
		while(frontIsClear()) {
			if(beepersPresent()) {
				pickBeeper();
			}
			move();
		}
		turnAround();
	}
	
	public void tryTurnAround() {
		// Turn around if Karel see the wall on the south and he can't move forward
		
		if(frontIsBlocked() && facingSouth()) {
			turnAround();
		}
	}
	
	public void tryMoveNorth() {
		// Explore the north part of column
		
		while(frontIsClear() && facingNorth()) {
			exploreNorth();
		}
		if(facingNorth()) {
			exploreNorth();
		}
	}
	
	public void tryMoveSouth() {
		// Explore the south part of column
		
		while(frontIsClear() && facingSouth()) {
			exploreSouth();
		}
		if(facingSouth()) {
			exploreSouth();
		}
	}
	
	public void exploreNorth() {
		// Try to find the exit from the column on the north
		
		if(rightIsClear()) {
			turnRight();
			move();
			turnRight();
			clearColumn();
		}else if(frontIsClear()){
			move();
		}
	}
	
	private void exploreSouth() {
		// Try to find the exit form the column on the south
		
		if(leftIsClear()) {
			turnLeft();
			move();
			if(frontIsClear()) {
				turnLeft();
			}else {
				turnRight();
			}
			clearColumn();
		}else if(frontIsClear()){
			move();
		}
	}
}
